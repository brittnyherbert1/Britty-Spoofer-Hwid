Run install.exe
Click “Install.” 
Wait for installation (usually about 30-50 seconds)
Click “Finish”
Follow the on-screen instructions to spoof your pc